#!/usr/bin/env python
# coding: utf-8

# In[62]:


import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import plotly.io as pio
pio.templates.default = "plotly_white"

data = pd.read_csv(r"D:\data set\t20-world-cup-22.csv")
print(data.head())


# In[63]:


# no. of matches won by each team 
figure = px.bar(data,
               x = data["winner"],
               title="Number of matches won by the teams in t20 worldcup.")

figure.show()


# In[64]:


won_by = data["won by"].value_counts()
label = won_by.index
counts = won_by.values
colors = ['yellow','red']

fig = go.Figure(data=[go.Pie(labels = label, values = counts)])
fig.update_layout(title_text="Number of matches won by runs or wickets")
fig.update_traces(hoverinfo='label+percent', textinfo='value', textfont_size= 30,
                 marker=dict(colors = colors, line =dict(color='black',width=3)))
fig.show()


# In[65]:


toss = data['toss decision'].value_counts()
label = toss.index
counts = toss.values
colors = ['skyblue','yellow']

fig = go.Figure(data=[go.Pie(labels=label, values=counts)])
fig.update_layout(title_text='toss decisions in t20 world cup 2022')
fig.update_traces(hoverinfo='label+percent', textinfo='value', textfont_size=30,
                 marker=dict(colors=colors, line=dict(color='black',width=3)))
fig.show()


# In[66]:


figure = px.bar(data,
               x=data["top scorer"],
                y=data["highest score"],
                color= data["highest score"],
                title="top scorers in t20 world cup 2022")
figure.show()


# In[67]:


figure=px.bar(data,
              x=data["player of the match"],
             title="player of the match awards in t20 world cup")
figure.show()


# In[68]:


figure=px.bar(data,
             x=data["best bowler"],
             title="best bowlers in t20 world cup 2022")
figure.show()


# In[69]:


fig = go.Figure()
fig.add_trace(go.Bar(
             x=data["venue"],
             y=data["first innings score"],
             name="first innings runs",
             marker_color = 'blue'))
fig.add_trace(go.Bar(
                x=data['venue'],
                y=data['second innings score'],
                name='second innings runs',
                marker_color = 'red'))
fig.update_layout(barmode='group',
                 xaxis_tickangle=-45,
                 title = 'best stadiums to bat first or chase')
fig.show()


# In[70]:


fig= go.Figure()
fig.add_trace(go.Bar(
x=data['venue'],
y=data['first innings wickets'],
name= 'first innings wickets',
marker_color= 'blue'))

fig.add_trace(go.Bar(
x=data['venue'],
y=data['second innings wickets'],
name= 'second innings wickets',
marker_color= 'red'))

fig.update_layout(barmode='group',
                 xaxis_tickangle=-45,
                 title='best stadium to bowl or defend')
fig.show()


# In[ ]:


#So some highlights of the t20 world cup 2022 we found from our analysis are:

    #England won the most number of matches
    #Virat Kohli scored highest in the most number of matches
    #Sam Curran was the best bowler in the most number of matches
    #More teams won by batting first
    #More teams decided to bat first
    #SCG was the best stadium to bat first
    #SCG was the best stadium to defend the target in the World Cup
    #The Optus Stadium was the best stadium to bowl first

